﻿using UnityEngine;
using System.Collections;

public class PullAndRelease : MonoBehaviour {

	// The default Position
	Vector2 startPos;
	Vector2 simetricPoint;
	Vector2 xPoint;
	public float force = 1300;


	void Start () {
		startPos = transform.position;
		xPoint.y = 0;
		xPoint.x = 3;

	}
	

	void OnMouseUp() {
		// ToDo: fire the Bird
		// Disable isKinematic
		GetComponent<Rigidbody2D>().isKinematic = false;
		
		// Add the Force
		Vector2 dir = startPos - (Vector2)transform.position;
		GetComponent<Rigidbody2D>().AddForce(dir * force);
		
		// Remove the Script (not the gameObject)
		Destroy(this);

	}
	
	void OnMouseDrag() {
		// ToDo: move the Bird
		// Convert mouse position to world position
		Vector2 p= Camera.main.ScreenToWorldPoint(Input.mousePosition);


		
		// Keep it in a certain radius
		float radius = 1.8f;
		Vector2 dir = p - startPos;
		if (dir.sqrMagnitude > radius)
			dir = dir.normalized * radius;

		// Set the Position
		transform.position = startPos + dir;

		print ("startPosX: " + startPos.x);
		print ("startPosY: " + startPos.y);

		print ("transform.position.x: " + transform.position.x);
		print ("transform.position.y: " + transform.position.y);

		float a = Mathf.Atan2 (startPos.y, startPos.y) * Mathf.Rad2Deg;

		float b = Mathf.Atan2 (transform.position.y, transform.position.x) * Mathf.Rad2Deg;
		//print ("b: " + b);

		/*Vector2 v = transform.position - startPos;
		print ("v.x: " + v.x);
		print ("v.y: " + v.y);*/

		Vector2 d = p - startPos;

		//y2-y1 / x2 - x1

		float m = transform.position.y - startPos.y / transform.position.y - startPos.x;
		print( "m: " + m);

		simetricPoint = transform.position * -1;

		//print ("simetricPoint.x" + simetricPoint.x * -1);
		//print ("simetricPoint.y" + simetricPoint.y * -1);

		print ("simetricPoint.x" + simetricPoint.x);
		print ("simetricPoint.y" + simetricPoint.y);


		float angle = Vector2.Angle (simetricPoint, xPoint);//a - b;
		print ("angle: " + angle);

		//Vector2.Angle (simetricPoint, xPoint);
	}


	void OnDrawGizmos()
	{
		// Draw a yellow sphere at the transform's position
		Gizmos.color = Color.yellow;
		Gizmos.DrawSphere(simetricPoint, 0.5f);

		Gizmos.color = Color.red;
		Gizmos.DrawSphere(xPoint, 0.5f);

	}
}
